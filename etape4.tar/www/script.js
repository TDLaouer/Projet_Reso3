document.getElementById("genial").addEventListener('click', function(e) {
    alert("Il va etre treeeeeeente");
});
