function big(x) {
	x.style.height="128px"; 
	x.style.width="128px"; 
}

